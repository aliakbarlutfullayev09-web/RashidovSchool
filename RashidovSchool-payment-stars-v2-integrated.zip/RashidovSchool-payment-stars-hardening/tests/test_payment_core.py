import unittest
from decimal import Decimal

from bot.services.payment_core import (
    PaymentError,
    normalize_amount,
    validate_provider_currency,
)


class PaymentValidationTests(unittest.TestCase):
    def test_normalizes_integer_amount(self):
        self.assertEqual(normalize_amount("1250", provider="click"), Decimal("1250.00"))

    def test_normalizes_decimal_amount(self):
        self.assertEqual(normalize_amount("10.5", provider="click"), Decimal("10.50"))

    def test_stars_are_integral(self):
        self.assertEqual(normalize_amount("5", provider="telegram_stars"), Decimal("5.00"))
        with self.assertRaises(PaymentError):
            normalize_amount("5.5", provider="telegram_stars")

    def test_rejects_zero(self):
        with self.assertRaises(PaymentError):
            normalize_amount("0", provider="click")

    def test_rejects_nan(self):
        with self.assertRaises(PaymentError):
            normalize_amount("NaN", provider="click")

    def test_rejects_infinity(self):
        with self.assertRaises(PaymentError):
            normalize_amount("Infinity", provider="click")

    def test_rejects_unsupported_precision(self):
        with self.assertRaises(PaymentError):
            normalize_amount("10.123", provider="click")

    def test_click_currency(self):
        validate_provider_currency("click", "UZS")

    def test_stars_currency(self):
        validate_provider_currency("telegram_stars", "XTR")

    def test_rejects_wrong_currency(self):
        with self.assertRaises(PaymentError):
            validate_provider_currency("telegram_stars", "UZS")

    def test_rejects_unknown_provider(self):
        with self.assertRaises(PaymentError):
            validate_provider_currency("other", "UZS")


if __name__ == "__main__":
    unittest.main()
