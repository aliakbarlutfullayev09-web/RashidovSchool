import unittest
from uuid import uuid4

from bot.services.telegram_stars import (
    PAYLOAD_PREFIX,
    parse_invoice_payload,
    successful_payment_hash,
    validate_pre_checkout_order,
)
from bot.services.payment_core import PaymentError


class TelegramStarsAdapterTests(unittest.TestCase):
    def test_parse_valid_order_payload(self):
        order_id = uuid4()
        self.assertEqual(parse_invoice_payload(f"{PAYLOAD_PREFIX}{order_id}"), order_id)

    def test_rejects_legacy_payload(self):
        with self.assertRaises(PaymentError):
            parse_invoice_payload("buy_neurons_5")

    def test_rejects_malformed_uuid(self):
        with self.assertRaises(PaymentError):
            parse_invoice_payload(f"{PAYLOAD_PREFIX}not-a-uuid")

    def test_payment_hash_is_stable(self):
        args = dict(payload=f"{PAYLOAD_PREFIX}{uuid4()}", user_id=123, currency="XTR",
                    total_amount=5, telegram_charge_id="charge-1", provider_charge_id="")
        self.assertEqual(successful_payment_hash(**args), successful_payment_hash(**args))

    def test_payment_hash_changes_if_amount_changes(self):
        args = dict(payload=f"{PAYLOAD_PREFIX}{uuid4()}", user_id=123, currency="XTR",
                    total_amount=5, telegram_charge_id="charge-1", provider_charge_id="")
        other = dict(args, total_amount=6)
        self.assertNotEqual(successful_payment_hash(**args), successful_payment_hash(**other))

    def test_precheckout_accepts_exact_matching_order(self):
        order_id = uuid4()
        order = {"user_id": 123, "provider": "telegram_stars", "expected_amount": 5,
                 "currency": "XTR", "status": "pending"}
        result = validate_pre_checkout_order(
            order, user_id=123, payload=f"{PAYLOAD_PREFIX}{order_id}",
            currency="XTR", total_amount=5
        )
        self.assertEqual(result, order_id)

    def test_precheckout_rejects_wrong_owner(self):
        order_id = uuid4()
        order = {"user_id": 123, "provider": "telegram_stars", "expected_amount": 5,
                 "currency": "XTR", "status": "pending"}
        with self.assertRaises(PaymentError):
            validate_pre_checkout_order(
                order, user_id=999, payload=f"{PAYLOAD_PREFIX}{order_id}",
                currency="XTR", total_amount=5
            )

    def test_precheckout_rejects_amount_currency_and_state_mismatch(self):
        order_id = uuid4()
        base = {"user_id": 123, "provider": "telegram_stars", "expected_amount": 5,
                "currency": "XTR", "status": "pending"}
        for overrides, currency, amount in [
            ({}, "XTR", 6), ({}, "UZS", 5), ({"status": "paid"}, "XTR", 5),
            ({"provider": "click"}, "XTR", 5),
        ]:
            with self.subTest(overrides=overrides, currency=currency, amount=amount):
                with self.assertRaises(PaymentError):
                    validate_pre_checkout_order(
                        dict(base, **overrides), user_id=123,
                        payload=f"{PAYLOAD_PREFIX}{order_id}", currency=currency,
                        total_amount=amount
                    )

    def test_precheckout_rejects_missing_order_and_non_integer_amount(self):
        order_id = uuid4()
        with self.assertRaises(PaymentError):
            validate_pre_checkout_order(None, user_id=123,
                payload=f"{PAYLOAD_PREFIX}{order_id}", currency="XTR", total_amount=5)
        order = {"user_id": 123, "provider": "telegram_stars", "expected_amount": 5,
                 "currency": "XTR", "status": "pending"}
        with self.assertRaises(PaymentError):
            validate_pre_checkout_order(order, user_id=123,
                payload=f"{PAYLOAD_PREFIX}{order_id}", currency="XTR", total_amount=True)


if __name__ == "__main__":
    unittest.main()
