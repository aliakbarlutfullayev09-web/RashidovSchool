-- Read-only preflight checks to run on STAGING before applying 001_payment_orders.sql.
-- Returns expected existing dependencies and relevant column definitions.
SELECT to_regclass('public.users') AS users_table,
       to_regclass('public.transactions') AS transactions_table;

SELECT table_name, column_name, data_type, is_nullable
FROM information_schema.columns
WHERE table_schema = 'public'
  AND table_name IN ('users', 'transactions')
  AND column_name IN ('telegram_id', 'balance', 'user_id', 'amount', 'type', 'description')
ORDER BY table_name, ordinal_position;

-- Ensure transaction type accepts the value used by payment_core.py.
SELECT conname, pg_get_constraintdef(oid) AS definition
FROM pg_constraint
WHERE conrelid = 'public.transactions'::regclass
  AND contype = 'c';
