# Telegram Stars implementation audit

## Existing code findings

- Existing handler uses `buy_neurons_<stars>` payload and credits balance from payload-derived values.
- `pre_checkout_handler` unconditionally approves every checkout.
- Successful payment credit and transaction record are separate DB operations.
- Existing deep-link entry point in `bot/handlers/start.py` calls `send_stars_invoice(message, stars)` without a DB pool. The new adapter requires `send_stars_invoice(message, stars, pool)`; see `integration-patch/start.py.diff`.

## Draft design

1. Create a unique order row with immutable user, provider, XTR amount, reward amount and UUID.
2. Mark order pending before publishing the invoice.
3. Validate payload, owner, order status, provider, currency and exact amount during pre-checkout.
4. On successful payment, validate Telegram payment fields and call the shared settlement core.
5. In a single PostgreSQL transaction, lock the order, record the unique event/ledger, increment user balance, insert the `topup` transaction, and mark the order paid.
6. Use unique database constraints to protect against duplicate event IDs and provider charge IDs even under concurrent delivery.

## Still unverified / blocking production

- The new adapter is not wired into the GitHub repository. Attempted branch creation was rejected by GitHub integration with HTTP 403; no repository files were changed.
- Live database state and permissions were not inspected; migration has not been applied.
- PostgreSQL integration tests have not run; this environment lacks PostgreSQL and `asyncpg`.
- The handler has not been runtime-tested against the exact aiogram version in the project.
- Telegram end-to-end tests, retry/restart tests, and recovery/reconciliation operations are still required.
- A confirmed Telegram charge followed by persistent database failure has a documented manual reconciliation path in `ops/RECONCILIATION_RUNBOOK.md`, with read-only checks in `ops/reconciliation.sql`. This path is not yet tested against a real staging DB or Telegram transaction record.
- No refund workflow is included, per the product requirement.

## Recovery-path status

The handler now logs correlated order/user/amount/currency and Telegram charge identifiers when settlement fails. An operator can use the runbook and read-only SQL report to investigate. This improves observability but is not an automatic guarantee of recovery; production remains blocked until replay is tested end-to-end with a verified staging payment.

## Honest reliability statement

No payment implementation can be guaranteed 100% error-free. This draft improves validation and transactional idempotency, but it must not be considered production-safe until the listed integration and recovery checks pass.
