# Как добавить Telegram Stars в Rashidov School безопасно

## Важно

Этот пакет пока не подключён к репозиторию и не готов к production. Не заменяйте `main` и не запускайте миграцию на рабочей базе.

## Безопасный путь через GitHub в браузере

1. Откройте https://github.com/aliakbarlutfullayev09-web/RashidovSchool
2. В списке веток создайте новую ветку от `main` с именем `payment-stars-hardening`. Если GitHub не позволяет создать ветку — остановитесь; не редактируйте `main` напрямую.
3. В новой ветке добавьте файлы из архива по тем же путям:
   - `migrations/001_payment_orders.sql`
   - `migrations/001_payment_orders_preflight.sql`
   - `bot/services/payment_core.py`
   - `bot/services/telegram_stars.py`
   - `bot/handlers/payments.py`
   - `tests/test_payment_core.py`
   - `tests/test_telegram_stars_adapter.py`
   - `ops/reconciliation.sql`
   - `ops/RECONCILIATION_RUNBOOK.md`
4. В `bot/handlers/start.py` НЕ заменяйте весь файл. Примените только небольшое изменение из `integration-patch/start.py.diff`: вызов должен передавать `pool` в `send_stars_invoice`.
5. Откройте Pull Request из `payment-stars-hardening` в `main`. Не сливайте его, пока staging-проверки из `STAGING_TEST_PLAN.md` не пройдены.

## Перед применением миграции

- Сделайте резервную копию базы.
- Выполните `migrations/001_payment_orders_preflight.sql` на отдельной тестовой базе и проверьте результаты.
- Проверьте существующие таблицы и типы столбцов; миграция написана как проектная заготовка и может потребовать адаптации под фактическую схему.
- Не применяйте миграцию в production до ревью и интеграционных тестов.

## Что уже проверено

В изолированной среде пройдены 20 unit-тестов и компиляция Python. PostgreSQL, установленная версия aiogram и end-to-end Telegram Stars не проверены. Это не является подтверждением production-готовности.
