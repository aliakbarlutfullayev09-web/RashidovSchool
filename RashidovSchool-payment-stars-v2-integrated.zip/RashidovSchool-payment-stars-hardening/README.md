# Rashidov School — Telegram Stars hardening draft

This package is **not production-ready and is not connected to the live repository**. It is a staging candidate only. No provider calls or real payments were made.

## Improvements included

- Separate immutable payment orders, event log and unique credit ledger.
- Strict order UUID payload; no reward amount is parsed from user-controlled payload text.
- Pre-checkout validation for order existence, Telegram user ownership, provider, `XTR`, exact integer amount and pending status.
- Successful-payment validation and atomic transaction for ledger entry, balance credit, transaction record and order status.
- Idempotency based on Telegram charge ID plus database unique constraints to prevent duplicate credits.
- Ambiguous invoice-send failures leave the order pending and emit a correlated log entry rather than risking cancellation of a delivered invoice.
- No refund workflow, as requested.

## Files

- `migrations/001_payment_orders.sql` — draft PostgreSQL migration.
- `bot/services/payment_core.py` — order creation and atomic settlement core.
- `bot/services/telegram_stars.py` — payload, event hash and pre-checkout validation helpers.
- `bot/handlers/payments.py` — adapter draft; replaces the current handler only after review.
- `integration-patch/start.py.diff` — required change to the current deep-link caller, which currently invokes `send_stars_invoice(message, stars)` without the DB pool.
- `tests/` — pure unit tests.
- `IMPLEMENTATION_NOTES.md` — unresolved production gates.
- `ops/reconciliation.sql` — read-only reports for stale orders and payment-ledger inconsistencies.
- `ops/RECONCILIATION_RUNBOOK.md` — manual recovery procedure for verified Telegram charges after database failures.

## Verification completed in this environment

- 20 unit tests passed.
- Python compile check passed.
- No PostgreSQL server/client or `asyncpg`/`aiogram` packages are installed here, so database integration and handler runtime tests could not be run.

## Required before live activation

1. Apply migration to an isolated staging database after schema review and backup.
2. Install project dependencies and run handler tests with the project's actual aiogram/asyncpg versions.
3. Apply the `start.py.diff` change and search all call sites of `send_stars_invoice` to update them consistently.
4. Run PostgreSQL integration tests covering duplicate and concurrent successful-payment updates, wrong user, wrong amount/currency, unknown order, and transaction rollback.
5. Test Telegram Stars in a controlled test setup, including delivery retry and bot restart.
6. Exercise `ops/RECONCILIATION_RUNBOOK.md` with a verified staging charge and a deliberately unavailable database; confirm recovery is idempotent.
7. Only then enable production handling.

## Safety and rollback

Nothing in this package has been deployed or written to the GitHub repository. To roll back this draft, do not apply its migration and discard this package. Existing production handlers and database remain unchanged.
