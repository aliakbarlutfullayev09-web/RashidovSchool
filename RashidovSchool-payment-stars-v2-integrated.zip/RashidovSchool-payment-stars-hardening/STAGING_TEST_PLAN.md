# Telegram Stars staging verification (no production payments)

This checklist is a release gate, not a claim that production is already verified.

## Preconditions

- Use a separate staging bot token and a separate PostgreSQL database.
- Confirm `bot/config.py` settings load and install the exact pinned project dependencies.
- Review the migration against the actual staging schema; take a database snapshot first.
- Keep production bot polling/deployment untouched.
- Do not add a refund workflow (product policy: no refunds).

## Required automated checks

1. Run `python -m unittest discover -s tests -v` from this directory.
2. Run `python -m compileall -q bot tests`.
3. Run migration against a fresh staging database and against a staging copy of the current schema.
4. Add/run PostgreSQL integration tests for the following cases:
   - one matching order credits exactly once;
   - exact same successful-payment update delivered twice;
   - two concurrent handlers for the same Telegram charge;
   - same Telegram charge submitted against a different order;
   - wrong owner, payload, currency, amount, missing user, and invalid order state;
   - injected exception after ledger insert but before balance update rolls back all writes;
   - process restart between invoice creation and payment;
   - PostgreSQL unavailable during pre-checkout (checkout must be declined);
   - PostgreSQL unavailable during successful-payment handling (no false success message, alert/reconciliation procedure works).
5. Test the exact installed aiogram version with mocked Bot API responses; no live charge.
6. Test a staging invoice with Telegram's supported test setup before considering production.

## Release blockers

- This environment currently has neither `asyncpg`, `aiogram`, nor PostgreSQL tooling installed, so database/provider integration tests have not run here.
- A successful Telegram payment may arrive while PostgreSQL is unavailable. The handler intentionally does not claim the balance was credited. An operator must follow `ops/RECONCILIATION_RUNBOOK.md` using Telegram transaction records and internal order/event/ledger records. Do not blindly credit by amount alone: multiple purchases can share a user and amount.
- A timeout while sending an invoice is ambiguous. The order is left pending rather than cancelled because Telegram may have accepted the invoice before the timeout.
- No real payments have been run. Do not deploy this patch to production until all release blockers are resolved.

## Rollback

1. Disable the new Stars entry point / roll back the application release.
2. Do not drop payment tables if they contain payment evidence; preserve them for reconciliation.
3. Only drop the new tables in a disposable staging database after confirming no test records need to be retained.
4. Existing production files were not changed by this archive. GitHub branch creation was denied by the connected integration, so there is no repository commit to revert.
