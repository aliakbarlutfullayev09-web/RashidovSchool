"""Telegram Stars adapter for Rashidov School's shared payment core.

This handler intentionally fails closed if the payment order does not match.
Apply migrations/001_payment_orders.sql in a staging database before enabling it.
"""
from __future__ import annotations

from uuid import uuid4
import logging

from aiogram import F, Router
from aiogram.types import LabeledPrice, Message, PreCheckoutQuery

from bot.services.payment_core import (
    PaymentError,
    create_order,
    mark_order_pending,
    settle_order,
    cancel_unissued_order,
)
from bot.services.telegram_stars import (
    PAYLOAD_PREFIX,
    parse_invoice_payload,
    successful_payment_hash,
    validate_pre_checkout_order,
)

router = Router()
logger = logging.getLogger(__name__)

# Existing product pricing, preserved from the current implementation:
# Stars paid -> Neurons credited.
STARS_PRICES = {
    5: 1250,
    100: 25000,
    400: 100000,
    600: 150000,
    1000: 250000,
    3500: 1000000,
}

PROVIDER = "telegram_stars"


async def send_stars_invoice(message: Message, stars: int, pool) -> None:
    """Create an immutable DB order and send its invoice; no arbitrary fallback rewards."""
    if type(stars) is not int or stars not in STARS_PRICES:
        await message.answer("Недопустимая сумма оплаты.")
        return
    if message.from_user is None:
        await message.answer("Не удалось определить пользователя. Попробуйте ещё раз.")
        return

    neurons = STARS_PRICES[stars]
    order_id = await create_order(
        pool,
        user_id=message.from_user.id,
        provider=PROVIDER,
        expected_amount=stars,
        currency="XTR",
        reward_amount=neurons,
        idempotency_key=str(uuid4()),
        metadata={"product": "neurons_topup", "stars": stars},
    )
    # Set pending before publishing the invoice to avoid a fast-checkout race.
    await mark_order_pending(pool, order_id=order_id, provider=PROVIDER)
    payload = f"{PAYLOAD_PREFIX}{order_id}"
    try:
        await message.answer_invoice(
            title=f"{neurons} Neurons",
            description=f"Пополнение баланса на {neurons} Neurons.",
            payload=payload,
            currency="XTR",
            prices=[LabeledPrice(label=f"{neurons} Neurons", amount=stars)],
            provider_token="",  # Telegram Stars requires an empty provider token.
        )
    except Exception:
        # A network timeout is ambiguous: Telegram may have accepted the invoice
        # even though this process did not receive the response. Do NOT cancel the
        # order here; a delivered invoice must remain settleable. Leave it pending
        # for safe retry/manual reconciliation and log its immutable order ID.
        logger.exception(
            "Telegram invoice send returned an error; order remains pending because "
            "delivery may be ambiguous. order_id=%s user_id=%s stars=%s",
            order_id, message.from_user.id, stars,
        )
        raise


@router.pre_checkout_query()
async def pre_checkout_handler(pre_checkout_query: PreCheckoutQuery, pool) -> None:
    """Telegram requires an answer; validate order, owner, currency and exact amount."""
    try:
        order_id = parse_invoice_payload(pre_checkout_query.invoice_payload)
        order = await pool.fetchrow(
            """SELECT user_id, provider, expected_amount, currency, status
               FROM payment_orders WHERE id=$1""",
            order_id,
        )
        validate_pre_checkout_order(
            order,
            user_id=pre_checkout_query.from_user.id,
            payload=pre_checkout_query.invoice_payload,
            currency=pre_checkout_query.currency,
            total_amount=pre_checkout_query.total_amount,
        )
    except (PaymentError, ValueError, TypeError):
        await pre_checkout_query.answer(
            ok=False,
            error_message="Не удалось проверить заказ. Вернитесь и создайте новый платёж.",
        )
        return
    except Exception:
        logger.exception("Telegram Stars pre-checkout validation failed")
        await pre_checkout_query.answer(
            ok=False,
            error_message="Проверка временно недоступна. Попробуйте позже.",
        )
        return

    await pre_checkout_query.answer(ok=True)


@router.message(F.successful_payment)
async def successful_payment_handler(message: Message, pool) -> None:
    payment = message.successful_payment
    if payment is None or message.from_user is None:
        return

    try:
        order_id = parse_invoice_payload(payment.invoice_payload)
        if payment.currency != "XTR":
            raise PaymentError("Wrong Telegram Stars currency")
        if type(payment.total_amount) is not int or payment.total_amount <= 0:
            raise PaymentError("Invalid Telegram Stars amount")
        if not payment.telegram_payment_charge_id:
            raise PaymentError("Missing Telegram charge ID")

        payload_hash = successful_payment_hash(
            payload=payment.invoice_payload,
            user_id=message.from_user.id,
            currency=payment.currency,
            total_amount=payment.total_amount,
            telegram_charge_id=payment.telegram_payment_charge_id,
            provider_charge_id=payment.provider_payment_charge_id or "",
        )
        outcome = await settle_order(
            pool,
            order_id=order_id,
            provider=PROVIDER,
            event_key=payment.telegram_payment_charge_id,
            event_type="successful_payment",
            provider_payment_id=payment.telegram_payment_charge_id,
            paid_amount=payment.total_amount,
            currency=payment.currency,
            payload_sha256=payload_hash,
            expected_user_id=message.from_user.id,
        )
    except (PaymentError, ValueError, TypeError) as exc:
        # Keep enough correlation data to reconcile a confirmed Telegram charge
        # if the database transaction failed. Never log bot tokens or credentials.
        logger.error(
            "Telegram Stars payment requires manual reconciliation: "
            "order_id=%s user_id=%s amount=%s currency=%s telegram_charge_id=%s "
            "provider_charge_id=%s reason=%s",
            locals().get("order_id", "unparsed"), message.from_user.id,
            getattr(payment, "total_amount", None), getattr(payment, "currency", None),
            getattr(payment, "telegram_payment_charge_id", None),
            getattr(payment, "provider_payment_charge_id", None), exc,
        )
        await message.answer(
            "Платёж получен, но заказ не удалось автоматически подтвердить. "
            "Не оплачивайте повторно — обратитесь в поддержку с ID платежа."
        )
        return
    except Exception:
        logger.exception(
            "Telegram Stars settlement failed; reconcile against Telegram transaction "
            "records. order_id=%s user_id=%s amount=%s currency=%s "
            "telegram_charge_id=%s provider_charge_id=%s",
            locals().get("order_id", "unparsed"), message.from_user.id,
            getattr(payment, "total_amount", None), getattr(payment, "currency", None),
            getattr(payment, "telegram_payment_charge_id", None),
            getattr(payment, "provider_payment_charge_id", None),
        )
        await message.answer(
            "Платёж получен, но подтверждение временно недоступно. "
            "Не оплачивайте повторно; обратитесь в поддержку, если баланс не обновится."
        )
        return

    if outcome == "credited":
        await message.answer("Оплата подтверждена. Neurons зачислены на ваш баланс.")
    else:
        await message.answer("Этот платёж уже обработан. Повторного начисления не было.")
