"""Shared, provider-agnostic payment order core for Rashidov School.

This module does not call Click or Telegram APIs. A provider adapter MUST
verify authenticity and all provider-specific fields before calling settle_order.
No refund workflow is implemented because the product policy is no refunds.
"""
from __future__ import annotations

import json
from decimal import Decimal, InvalidOperation
from typing import Any
from uuid import UUID


class PaymentError(ValueError):
    """A payment event failed validation or violated an order invariant."""


PROVIDER_CURRENCY = {"click": "UZS", "telegram_stars": "XTR"}


def normalize_amount(value: Any, *, provider: str | None = None) -> Decimal:
    """Normalize amounts without binary float arithmetic; Stars must be integral."""
    try:
        amount = Decimal(str(value))
    except (InvalidOperation, ValueError, TypeError) as exc:
        raise PaymentError("Invalid payment amount") from exc
    if not amount.is_finite() or amount <= 0:
        raise PaymentError("Payment amount must be positive and finite")
    if provider == "telegram_stars" and amount != amount.to_integral_value():
        raise PaymentError("Telegram Stars amount must be an integer")
    # Persist money with a fixed two-decimal scale. Stars are integral XTR units.
    try:
        normalized = amount.quantize(Decimal("0.01"))
    except InvalidOperation as exc:
        raise PaymentError("Invalid payment amount precision") from exc
    if normalized != amount:
        raise PaymentError("Payment amount has unsupported precision")
    return normalized


def validate_provider_currency(provider: str, currency: str) -> None:
    expected = PROVIDER_CURRENCY.get(provider)
    if expected is None:
        raise PaymentError("Unsupported payment provider")
    if currency != expected:
        raise PaymentError(f"Currency mismatch: expected {expected}")


async def create_order(
    pool,
    *,
    user_id: int,
    provider: str,
    expected_amount: Any,
    currency: str,
    reward_amount: int,
    idempotency_key: str | None = None,
    metadata: dict | None = None,
) -> UUID:
    """Create an order with an immutable expected amount/reward.

    If an idempotency key is supplied, a retry returns the same order only when
    all material order parameters match exactly.
    """
    validate_provider_currency(provider, currency)
    amount = normalize_amount(expected_amount, provider=provider)
    if type(user_id) is not int or user_id <= 0:
        raise PaymentError("Invalid user ID")
    if type(reward_amount) is not int or reward_amount <= 0:
        raise PaymentError("Reward amount must be a positive integer")
    if idempotency_key is not None and not idempotency_key.strip():
        raise PaymentError("Idempotency key cannot be blank")
    if metadata is not None and not isinstance(metadata, dict):
        raise PaymentError("Metadata must be an object")

    async with pool.acquire() as conn:
        row = await conn.fetchrow(
            """INSERT INTO payment_orders
                   (user_id, provider, expected_amount, currency, reward_amount,
                    idempotency_key, metadata)
               VALUES ($1, $2, $3, $4, $5, $6, $7::jsonb)
               ON CONFLICT (user_id, provider, idempotency_key)
                   WHERE idempotency_key IS NOT NULL
               DO NOTHING
               RETURNING id""",
            user_id, provider, amount, currency, reward_amount,
            idempotency_key, json.dumps(metadata or {}),
        )
        if row:
            return row["id"]
        # This lookup is only reached after the partial unique-index conflict.
        existing = await conn.fetchrow(
            """SELECT id, expected_amount, currency, reward_amount
               FROM payment_orders
               WHERE user_id=$1 AND provider=$2 AND idempotency_key=$3""",
            user_id, provider, idempotency_key,
        )
        if not existing:
            raise PaymentError("Could not create or retrieve order")
        if (Decimal(existing["expected_amount"]) != amount
                or existing["currency"] != currency
                or existing["reward_amount"] != reward_amount):
            raise PaymentError("Idempotency key reused with different order parameters")
        return existing["id"]


async def mark_order_pending(pool, *, order_id: UUID, provider: str) -> None:
    """Move a newly created order to pending; safe to retry."""
    async with pool.acquire() as conn:
        result = await conn.execute(
            """UPDATE payment_orders SET status='pending', updated_at=NOW()
               WHERE id=$1 AND provider=$2 AND status='created'""",
            order_id, provider,
        )
        if result == "UPDATE 0":
            row = await conn.fetchrow(
                "SELECT status FROM payment_orders WHERE id=$1 AND provider=$2",
                order_id, provider,
            )
            if not row or row["status"] not in ("pending", "paid"):
                raise PaymentError("Order cannot be marked pending")


async def settle_order(
    pool,
    *,
    order_id: UUID,
    provider: str,
    event_key: str,
    event_type: str,
    provider_payment_id: str,
    paid_amount: Any,
    currency: str,
    payload_sha256: str,
    expected_user_id: int | None = None,
) -> str:
    """Validate and credit one order atomically; returns 'credited'/'duplicate'.

    Call only after the provider adapter has verified the notification signature,
    merchant/service identity, payment state, order mapping, and all required
    provider-specific fields. Database constraints are the final idempotency guard.
    """
    validate_provider_currency(provider, currency)
    paid = normalize_amount(paid_amount, provider=provider)
    if not isinstance(order_id, UUID):
        raise PaymentError("Invalid order ID")
    if not event_key or not event_key.strip() or not provider_payment_id or not provider_payment_id.strip():
        raise PaymentError("Missing provider event/payment ID")
    if not event_type or not event_type.strip():
        raise PaymentError("Missing provider event type")
    if (not isinstance(payload_sha256, str) or len(payload_sha256) != 64
            or any(ch not in "0123456789abcdef" for ch in payload_sha256.lower())):
        raise PaymentError("A valid SHA-256 hash of the verified provider payload is required")

    async with pool.acquire() as conn:
        async with conn.transaction():
            order = await conn.fetchrow(
                "SELECT * FROM payment_orders WHERE id=$1 FOR UPDATE", order_id
            )
            if not order:
                raise PaymentError("Unknown payment order")
            if order["provider"] != provider:
                raise PaymentError("Provider does not match order")
            if expected_user_id is not None and order["user_id"] != expected_user_id:
                raise PaymentError("Payment user does not own this order")
            if order["currency"] != currency:
                raise PaymentError("Currency does not match order")
            if Decimal(order["expected_amount"]) != paid:
                raise PaymentError("Paid amount does not match order")

            # Check event identity before writing a new event. Reusing the same
            # provider event ID for a different order/payload is not a duplicate.
            prior_event = await conn.fetchrow(
                """SELECT order_id, event_type, payload_sha256, outcome
                   FROM payment_events WHERE provider=$1 AND event_key=$2""",
                provider, event_key,
            )
            if prior_event:
                if (prior_event["order_id"] != order_id
                        or prior_event["event_type"] != event_type
                        or prior_event["payload_sha256"] != payload_sha256):
                    raise PaymentError("Provider event key was reused with different data")
                if prior_event["outcome"] in ("processed", "duplicate"):
                    return "duplicate"
                # No non-terminal event should normally persist because event
                # handling and settlement commit in the same transaction.
                raise PaymentError("Provider event is in an unexpected state")

            event = await conn.fetchrow(
                """INSERT INTO payment_events
                       (provider, event_key, order_id, event_type, payload_sha256)
                   VALUES ($1, $2, $3, $4, $5)
                   ON CONFLICT (provider, event_key) DO NOTHING
                   RETURNING id""",
                provider, event_key, order_id, event_type, payload_sha256,
            )
            # Covers a race between the prior-event read and the insert.
            if not event:
                raise PaymentError("Concurrent duplicate event; retry the verified event")

            if order["status"] == "paid":
                if order["provider_payment_id"] != provider_payment_id:
                    raise PaymentError("Order already paid with a different provider payment ID")
                await conn.execute(
                    """UPDATE payment_events SET outcome='duplicate', processed_at=NOW()
                       WHERE id=$1""", event["id"],
                )
                return "duplicate"
            if order["status"] not in ("created", "pending"):
                raise PaymentError(f"Order status {order['status']} cannot be settled")

            # Unique index on (provider, provider_payment_id) prevents the same
            # provider charge from settling two different orders under concurrency.
            await conn.execute(
                """INSERT INTO payment_ledger (order_id, user_id, reward_amount,
                                               provider, provider_payment_id)
                   VALUES ($1, $2, $3, $4, $5)""",
                order_id, order["user_id"], order["reward_amount"],
                provider, provider_payment_id,
            )
            result = await conn.execute(
                "UPDATE users SET balance=balance+$1 WHERE telegram_id=$2",
                order["reward_amount"], order["user_id"],
            )
            if result != "UPDATE 1":
                raise PaymentError("Order owner does not exist; credit was not applied")
            await conn.execute(
                """INSERT INTO transactions (user_id, amount, type, description)
                   VALUES ($1, $2, 'topup', $3)""",
                order["user_id"], order["reward_amount"],
                f"Payment {provider}: order {order_id}",
            )
            await conn.execute(
                """UPDATE payment_orders
                   SET status='paid', provider_payment_id=$1, paid_at=NOW(), updated_at=NOW()
                   WHERE id=$2""",
                provider_payment_id, order_id,
            )
            await conn.execute(
                """UPDATE payment_events SET outcome='processed', processed_at=NOW()
                   WHERE id=$1""", event["id"],
            )
    return "credited"


async def cancel_unissued_order(pool, *, order_id: UUID, provider: str) -> bool:
    """Cancel an order if invoice creation failed before the user could pay it."""
    async with pool.acquire() as conn:
        result = await conn.execute(
            """UPDATE payment_orders SET status='cancelled', updated_at=NOW()
               WHERE id=$1 AND provider=$2 AND status IN ('created', 'pending')""",
            order_id, provider,
        )
        return result == "UPDATE 1"
