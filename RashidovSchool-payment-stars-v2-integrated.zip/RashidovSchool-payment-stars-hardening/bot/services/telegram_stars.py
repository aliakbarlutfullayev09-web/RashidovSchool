"""Pure validation helpers for Telegram Stars invoices and payment events."""
from __future__ import annotations

import hashlib
import json
from uuid import UUID
from decimal import Decimal

from bot.services.payment_core import PaymentError

PAYLOAD_PREFIX = "rashidov_stars_v2:"


def parse_invoice_payload(payload: str) -> UUID:
    """Parse only a v2 order UUID; legacy arbitrary amounts are rejected."""
    if not isinstance(payload, str) or not payload.startswith(PAYLOAD_PREFIX):
        raise PaymentError("Unknown invoice payload format")
    raw_order_id = payload[len(PAYLOAD_PREFIX):]
    try:
        order_id = UUID(raw_order_id)
    except (ValueError, TypeError, AttributeError) as exc:
        raise PaymentError("Invalid order ID in invoice payload") from exc
    if str(order_id) != raw_order_id.lower():
        raise PaymentError("Non-canonical order ID in invoice payload")
    return order_id


def successful_payment_hash(*, payload: str, user_id: int, currency: str,
                            total_amount: int, telegram_charge_id: str,
                            provider_charge_id: str) -> str:
    """Stable hash of the material Telegram payment fields used for deduplication."""
    body = {
        "payload": payload,
        "user_id": user_id,
        "currency": currency,
        "total_amount": total_amount,
        "telegram_payment_charge_id": telegram_charge_id,
        "provider_payment_charge_id": provider_charge_id,
    }
    encoded = json.dumps(body, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def validate_pre_checkout_order(
    order: dict, *, user_id: int, payload: str, currency: str, total_amount: int
) -> UUID:
    """Pure fail-closed validation for a Telegram pre-checkout query."""
    order_id = parse_invoice_payload(payload)
    if type(user_id) is not int or user_id <= 0:
        raise PaymentError("Invalid Telegram user ID")
    if currency != "XTR":
        raise PaymentError("Wrong Telegram Stars currency")
    if type(total_amount) is not int or total_amount <= 0:
        raise PaymentError("Invalid Telegram Stars total amount")
    if not order:
        raise PaymentError("Unknown payment order")
    if order["user_id"] != user_id:
        raise PaymentError("Order owner mismatch")
    if order["provider"] != "telegram_stars" or order["currency"] != "XTR":
        raise PaymentError("Order provider/currency mismatch")
    if Decimal(str(order["expected_amount"])) != Decimal(total_amount):
        raise PaymentError("Payment amount does not match order")
    if order["status"] != "pending":
        raise PaymentError("Order is not awaiting payment")
    return order_id
